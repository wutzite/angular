import { Injectable } from '@angular/core';
//import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AccountManagerService {
  state:boolean = false;
  changed:boolean = false;
  constructor() {
  }

//  private messageSource = new BehaviorSubject('default message');
//  currentMessage = this.messageSource.asObservable();

  getState(){
    return this.state;
  }
  setState(newState:boolean){
    if(newState == false){
      this.state = false;
    }else{
      if(this.state){
        this.state = false;
      }else{
        this.state = true;
      }
    }
  }
}
