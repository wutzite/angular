import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';

import {MatDialog, MatDialogConfig} from "@angular/material";

@Component({
  selector: 'app-inactive',
  templateUrl: './inactive.component.html',
  styleUrls: ['./inactive.component.css']

})
export class InactiveComponent implements OnInit {

  //constructor(private route: ActivatedRoute, private router: Router, private location: Location) { }
  constructor(private dialog: MatDialog) { }

  ngOnInit() {
  }

  openDialog() {

    //const dialogConfig = new MatDialogConfig();

    //dialogConfig.disableClose = true;
    //dialogConfig.autoFocus = true;

    //this.dialog.open(LogoutComponent, dialogConfig);
  }
}
