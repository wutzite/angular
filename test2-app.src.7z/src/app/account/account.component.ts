import { Component, OnInit } from '@angular/core';
import { AccountManagerService } from '../account-manager.service';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule,Route } from '@angular/router';

import { trigger, state, transition, style, query, group, animateChild,animate } from '@angular/animations';

export const slideInAnimation2 =
trigger('routeAnimations', [
  transition('* => LoginPage', [
    style({ backgroundColor:'green'}),animate(1000),
  ]),
  transition('* => LogoutPage', [
    style({ backgroundColor:'yellow'}),animate(1000),
  ])
]);

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.css'],
  animations: [
    slideInAnimation2
    // animation triggers go here
  ]
})


export class AccountComponent implements OnInit {

  //public AccountManager:AccountManagerService = null;
  constructor(private AccountManager:AccountManagerService) {
    //this.AccountManager = new AccountManagerService();
   }

  ngOnInit() {
  }


}

