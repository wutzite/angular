import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActiveComponent } from './active/active.component';
import { InactiveComponent } from './inactive/inactive.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { LoginDialogComponent } from './login-dialog/login-dialog.component';

import { RouterModule } from '@angular/router';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatDialog,MatDialogModule,MatDialogRef,MAT_DIALOG_DATA } from '@angular/material/dialog';

//import { trigger, state, style, animate, transition } from '@angular/animations';

@NgModule({
  declarations: [
    LoginComponent,
    LogoutComponent,
    ActiveComponent,
    InactiveComponent,
    LoginDialogComponent
  ],
  imports: [
    CommonModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatDialogModule,
    RouterModule.forRoot([
      { path: '', component: InactiveComponent,data: {animation: 'LoginPage'} },
      { path: 'inactive', component: InactiveComponent,data: {animation: 'LoginPage'} },
      { path: 'active', component: ActiveComponent,data: {animation: 'LogoutPage'} }
    ])
  ],
  exports: [
    ActiveComponent,
    InactiveComponent,
    LoginComponent,
    LogoutComponent,
      FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatDialogModule
  ],
  entryComponents:[LoginDialogComponent]
})
export class AccountModule {
 }
