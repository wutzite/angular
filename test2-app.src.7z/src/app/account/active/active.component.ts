import { Component, OnInit } from '@angular/core';
//import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { MatDialog, MatDialogRef, MatDialogConfig } from '@angular/material/dialog';
import { LoginDialogComponent } from "../login-dialog/login-dialog.component";

@Component({
  selector: 'app-active',
  templateUrl: './active.component.html',
  styleUrls: ['./active.component.css']
})
export class ActiveComponent implements OnInit {

  //constructor(private route: ActivatedRoute, private router: Router, private location: Location) { }
  //constructor() { }
  constructor(public dialog: MatDialog) {}

  ngOnInit() {
  }

  onSubmit(){
    const dialogConfig = new MatDialogConfig();
    //dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.height = '200px';
    dialogConfig.width = '100%';
    /*
    dialogConfig.position = {
      top: '0',
      left: '0'
    };*/
    dialogConfig.data = {title:'test'};

    let dialogRef = this.dialog.open(LoginDialogComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }
}
