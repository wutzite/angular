import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';

@Component({
  selector: 'app-active',
  templateUrl: './active.component.html',
  styleUrls: ['./active.component.css']
})
export class ActiveComponent implements OnInit {

  //constructor(private route: ActivatedRoute, private router: Router, private location: Location) { }
  constructor() { }

  ngOnInit() {
  }
  onSubmit(){
    let dialogRef = dialog.open(UserProfileComponent, {
      height: '400px',
      width: '600px',
    });
  }
}
