import { Component, OnInit } from '@angular/core';
import { AccountManagerService } from '../../account-manager.service';
import { trigger, state, style, animate, transition } from '@angular/animations';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  //constructor(private AccountManager:AccountManagerService) { }
  //constructor(private AccountManager:AccountManagerService,private route: ActivatedRoute, private router: Router, private location: Location) { }
  constructor(private AccountManager:AccountManagerService,private router: Router) { }

  ngOnInit() {
  }
  
  onSubmit(){
    console.log("login.");
    this.AccountManager.setState(true);
    alert("login");
    this.router.navigate(['/active']);
  }
}
