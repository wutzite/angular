import { Injectable } from '@angular/core';
//import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AccountManagerService {
  state:boolean = false;
  constructor() {
  }

//  private messageSource = new BehaviorSubject('default message');
//  currentMessage = this.messageSource.asObservable();

  getState(){
    return this.state;
  }
  setState(){
    if(this.state){
      this.state = false;
    }else{
      this.state = true;
    }
  }
}
