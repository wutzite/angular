import { Component, OnInit } from '@angular/core';
import { AccountManagerService } from '../../account-manager.service';
/*
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
*/

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private AccountManager:AccountManagerService) { }

  ngOnInit() {
  }

  onSubmit(){
    console.log("login.");
    this.AccountManager.setState();
    alert("login");
  }
}
