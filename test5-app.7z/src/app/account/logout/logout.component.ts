import { Component, OnInit } from '@angular/core';
import { AccountManagerService } from '../../account-manager.service';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.css']
})
export class LogoutComponent implements OnInit {

  constructor(private AccountManager:AccountManagerService) { }

  ngOnInit() {
  }
  onSubmit(){
    console.log("logout.");
    this.AccountManager.setState();
    alert("blogout");
  }
}
