import { Component, OnInit } from '@angular/core';
import { AccountManagerService } from '../account-manager.service';

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.css']
})
export class AccountComponent implements OnInit {

  //public AccountManager:AccountManagerService = null;
  constructor(private AccountManager:AccountManagerService) {
    //this.AccountManager = new AccountManagerService();
   }

  ngOnInit() {
  }

}
